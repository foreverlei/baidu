# -*- coding: utf-8 -*-
from pymongo import MongoClient
import urllib2,time,json
from lxml import etree
import HTMLParser
import requests 
import sys
reload(sys)
sys.setdefaultencoding('utf8')

class DB(object):
    def __init__(self):
        self.mongoUri = 'mongodb://admin:Aa123456@176.122.177.50:27017'
        self.mongodbHost = 'mongodb://176.122.177.50'
        self.mongodbPort = 27017
        self.username = 'admin'
        self.password = 'Aa123456'

    def connect(self):
        self.dbClient = MongoClient(self.mongoUri)
        # self.dbClient.pan.authenticate(self.username, self.password)
        self.db = self.dbClient.pan
        self.collectionShareFiles = self.db.shareFiles
        # self.collectionShareFiles.save({"name":"name","uk":"uk"})
        # print(self.collectionShareFiles.index_information())
        # indexlist=self.collectionShareFiles.list_indexes()
        indexlist=self.collectionShareFiles.index_information()
        for index in indexlist:
            print(index)
        if not indexlist.has_key("uk_1"):
            self.collectionShareFiles.create_index([('uk',1)])

    def save(self,data):
        if data:
            oldData = self.collectionShareFiles.find_one({"uk":data["uk"]}) 
            if oldData:
                oldFiles = oldData["files"]
                needRefresh = False
                for item in data["files"]:
                    if oldFiles.index(item) < 0:
                        oldFiles.append(item)
                        needRefresh = True
                if needRefresh:
                    self.collectionShareFiles.update({"uk":data["uk"]},{'$set':{"files":oldFiles}})

            else:
                self.collectionShareFiles.save(data)

    def disconnect(self):
        if self.dbClient:
            self.dbClient.close()

class SpiderPanDuoDuo(object):
    def __init__(self):
        self.baseUrl = 'http://www.panduoduo.net'
        self.startPage = 1
        self.endPage = 1
    
    def start(self):
        for current in range(self.startPage,self.endPage+1):
            fullUrl = self.baseUrl +"/u/bd/" + str(current)
            html =  etree.HTML(self.fetchPage(fullUrl))
            # result = etree.tostring(html)
            # print(result.decode("utf-8"))
            htmlUser = html.xpath("//div[@class='user']")
            for index, link in enumerate(htmlUser):
                
                avatar = link.xpath("//img[@class='avatar']/@src")
                username = link.xpath("//div[@class='info']/a[2]/text()")
                uks = link.xpath("//div[@class='info']/a[1]/@href")
                ukParam =  uks[index]
                uk = uks[index][6:]
            
                name = username[index].encode('utf-8')
                userObj = {"userName":name,"uk":uk,"avatar":avatar[index],"files":[]}

                userShareUrl = self.baseUrl + ukParam
                userHtml =  etree.HTML(self.fetchPage(userShareUrl))
                htmlShare = userHtml.xpath("//td[@class='t1']/a")
                if len(htmlShare) < 1:
                    print(userShareUrl,"length < 1------------------------") 
                for index2,link2 in enumerate(htmlShare):
                    fileName = link2.text
                    fileUrl = link2.attrib["href"]
                    # print(fileName)
                    print(fileUrl)
                    # print(link2.text)

                    userFileUrl = self.baseUrl + fileUrl
                    userFileHtml = etree.HTML(self.fetchPage(userFileUrl))
                    # result = etree.tostring(userFileHtml)
                    # print(result.decode("utf-8"))
                    htmlFileShortUrl= userFileHtml.xpath("//a[@class='dbutton2']")
                    if len(htmlFileShortUrl) > 2:
                        htmlFileShort = htmlFileShortUrl[0].attrib["href"]
                        htmlFileDir = htmlFileShortUrl[1].attrib["href"]

                    else:
                        htmlFileShort = None
                        htmlFileDir = htmlFileShortUrl[0].attrib["href"]

                    if htmlFileShort:
                        shortFileHtml = etree.HTML(self.fetchPage(htmlFileShort))
                        shortFileUrl = shortFileHtml.xpath("//div[@class='main']/a/@href")
                    else:
                        shortFileUrl = ""
                    if htmlFileDir:
                        shortDirHtml = etree.HTML(self.fetchPage(htmlFileDir))
                        shortDirUrl = shortDirHtml.xpath("//div[@class='main']/a/@href")
                    else:
                        shortDirUrl = ""
                    
                    userObj["files"].append({"fileName":fileName,"fileUrl":shortFileUrl,"fileDirUrl":shortDirUrl})

                
                db.save(userObj)
                time.sleep(2)

    def fetchPage(self,url,ref=None,reget=5):
        try:
            print(url)
            # request = urllib2.Request(url)
            # request.add_header('User-Agent', 'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36')
            # if ref:
            #     request.add_header('Referer',ref)
            # page = urllib2.urlopen(request,timeout=10)
            # html = page.read()
            headers= {'User-Agent':'Mozilla/5.0 (Windows NT 6.3; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/42.0.2311.135 Safari/537.36'}
            page = requests.get(url,headers=headers)

            html = page.text

    	except:
	    	if reget>=1:
                 #如果fetchPage失败，则再次尝试5次
                 print('fetchPage error,reget...' + str(6-reget) )
                 time.sleep(2)
                 return self.fetchPage(url,ref,reget-1)
    		else:
                 print 'request url:'+url
                 print 'failed to fetch html'
                 exit()
    	else:
	    	# return HTMLParser.HTMLParser().unescape(html)
            return html



if __name__ == "__main__":
    global db
    db =  DB()
    db.connect()
    spider = SpiderPanDuoDuo()
    spider.start()